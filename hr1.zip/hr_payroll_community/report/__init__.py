#-*- coding:utf-8 -*-

from . import report_payslip_details
from . import report_contribution_register
